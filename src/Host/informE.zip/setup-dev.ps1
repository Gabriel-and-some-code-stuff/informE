﻿# setup-dev.ps1 — ambiente informE sem privilégio de admin
# Uso: powershell -ExecutionPolicy Bypass -File setup-dev.ps1
#
# Pré-condições (já instalados pela TI ou pelo time):
#   - Git
#   - Docker Desktop (com WSL2 backend)
#
# O que este script instala (tudo em $HOME/$LOCALAPPDATA, sem UAC):
#   - .NET 10 SDK  → $env:LOCALAPPDATA\dotnet
#   - MAUI workload (maui-windows)
#   - gh CLI       → $HOME\.local\gh\<versao>\bin

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── 0. Pré-voo: WSL + Docker ─────────────────────────────────────────────────
Write-Host "`n[0/4] Verificando WSL e Docker" -ForegroundColor Cyan

# WSL: REGDB_E_CLASSNOTREG significa instalação corrompida — detecta antes de qualquer coisa.
$wslOut = & wsl --status 2>&1
if ($LASTEXITCODE -ne 0 -or ($wslOut -join '') -match 'corrompida|corrupted|REGDB') {
    Write-Warning @"
WSL parece corrompido (erro comum apos atualizacao do Windows).
Corrija com admin ANTES de continuar:

  1. PowerShell como Administrador:
       Get-AppxPackage -Name "*WindowsSubsystemForLinux*" | Remove-AppxPackage
  2. Reinicie o computador.
  3. Instale pelo Microsoft Store (pesquise "Windows Subsystem for Linux")
     OU no PowerShell como Administrador:
       Invoke-WebRequest -Uri "https://github.com/microsoft/WSL/releases/latest/download/wsl.latest.x64.msi" -OutFile "$env:TEMP\wsl.msi" -UseBasicParsing
       Start-Process msiexec.exe -ArgumentList "/i $env:TEMP\wsl.msi /quiet" -Wait
  4. Reinicie novamente.

Depois rode este script de novo.
"@
    exit 1
}
Write-Host "  WSL OK"

# Docker Desktop: verifica se o daemon responde.
$dockerOk = & docker info 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Warning @"
Docker Desktop nao esta respondendo.
Abra o Docker Desktop, aguarde o icone ficar verde na bandeja e rode o script de novo.
Se o Docker nao abre, corrija o WSL primeiro (veja acima).
"@
    exit 1
}
Write-Host "  Docker OK"

function Add-ToUserPath($dir) {
    $current = [Environment]::GetEnvironmentVariable('PATH', 'User')
    if ($current -notlike "*$dir*") {
        [Environment]::SetEnvironmentVariable('PATH', "$dir;$current", 'User')
        $env:PATH = "$dir;$env:PATH"
        Write-Host "  PATH atualizado: $dir" -ForegroundColor DarkGray
    }
}

function Test-Command($cmd) { $null -ne (Get-Command $cmd -ErrorAction SilentlyContinue) }

# ── 1. Git ───────────────────────────────────────────────────────────────────
Write-Host "`n[1/4] Git" -ForegroundColor Cyan
if (Test-Command git) {
    Write-Host "  OK — $(git --version)"
} else {
    Write-Error "Git nao encontrado. Instale o Git Portable (https://git-scm.com/download/win) e reabra o terminal."
}

# ── 2. .NET 10 SDK ───────────────────────────────────────────────────────────
Write-Host "`n[2/4] .NET 10 SDK" -ForegroundColor Cyan
$dotnetDir = "$env:LOCALAPPDATA\dotnet"
$needDotnet = $true

if (Test-Command dotnet) {
    $ver = dotnet --version 2>$null
    if ($ver -match '^10\.') {
        Write-Host "  OK — .NET $ver"
        $needDotnet = $false
    } else {
        Write-Host "  Versao atual: $ver — instalando .NET 10 em paralelo em $dotnetDir ..."
    }
}

if ($needDotnet) {
    Write-Host "  Baixando dotnet-install.ps1 (Microsoft oficial)..."
    $installer = "$env:TEMP\dotnet-install.ps1"
    Invoke-WebRequest -Uri 'https://dot.net/v1/dotnet-install.ps1' -OutFile $installer -UseBasicParsing
    & powershell -ExecutionPolicy Bypass -File $installer -Channel '10.0' -InstallDir $dotnetDir
    Add-ToUserPath $dotnetDir
    Write-Host "  .NET 10 instalado."
}

if ($env:PATH -notlike "*$dotnetDir*") { $env:PATH = "$dotnetDir;$env:PATH" }

# MAUI workload
$workloads = dotnet workload list 2>$null
if ($workloads -notlike '*maui-windows*') {
    Write-Host "  Instalando workload maui-windows (pode demorar ~5 min na 1a vez)..."
    dotnet workload install maui-windows --skip-sign-check
} else {
    Write-Host "  Workload maui-windows OK."
}

# ── 3. gh CLI ────────────────────────────────────────────────────────────────
Write-Host "`n[3/4] gh CLI" -ForegroundColor Cyan

if (Test-Command gh) {
    Write-Host "  OK — $(gh --version | Select-Object -First 1)"
} else {
    Write-Host "  Baixando gh CLI (sem admin, via zip)..."
    $release = Invoke-RestMethod 'https://api.github.com/repos/cli/cli/releases/latest'
    $asset   = $release.assets | Where-Object { $_.name -like '*windows_amd64.zip' } | Select-Object -First 1
    $zip     = "$env:TEMP\gh.zip"
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zip -UseBasicParsing
    $ghRoot  = "$HOME\.local\gh"
    Expand-Archive -Path $zip -DestinationPath $ghRoot -Force
    $ghBin   = (Get-ChildItem $ghRoot -Directory | Select-Object -First 1).FullName + '\bin'
    Add-ToUserPath $ghBin
    Write-Host "  gh CLI instalado em $ghBin"
}

# ── 4. Banco: Docker Compose + migrations ────────────────────────────────────
# Só sobe o banco se este script rodar de dentro do repo (existe docker-compose.yml).
if (Test-Path "$PSScriptRoot\docker-compose.yml") {
    Write-Host "`n[4/4] Banco de dados" -ForegroundColor Cyan

    Write-Host "  Subindo Postgres via docker compose..."
    docker compose -f "$PSScriptRoot\docker-compose.yml" up -d

    # Espera o healthcheck do container ficar 'healthy' antes de aplicar migrations.
    Write-Host "  Aguardando o Postgres aceitar conexao..."
    $healthy = $false
    foreach ($i in 1..20) {
        $state = docker inspect --format '{{.State.Health.Status}}' informe-postgres 2>$null
        if ($state -eq 'healthy') { $healthy = $true; break }
        Start-Sleep -Seconds 3
    }

    if ($healthy) {
        # NAO roda mais `dotnet ef database update` aqui. O proprio Server aplica
        # as migrations e semeia no boot (ver DatabaseBootstrapper), entao isto
        # era redundante — e pior: exigia a tool `dotnet-ef` instalada, que nenhum
        # passo deste script instala. Com $ErrorActionPreference='Stop', o setup
        # inteiro morria no ultimo passo, depois de ja ter instalado .NET, MAUI e gh.
        Write-Host "  Postgres pronto."
    } else {
        Write-Warning "  Postgres nao ficou 'healthy' a tempo. Rode manualmente: docker compose up -d"
    }
} else {
    Write-Host "`n  (rode dentro do repo clonado para subir o banco automaticamente)" -ForegroundColor DarkGray
}

# ── Certificado de desenvolvimento ────────────────────────────────────────────
# O Server roda em https://localhost:5021 e os hubs SignalR sobem como wss://.
# Sem confiar no dev-cert, o navegador barra o Scalar e o agente nem conecta.
Write-Host "`n[extra] Confiando no certificado de desenvolvimento do .NET..." -ForegroundColor Cyan
dotnet dev-certs https --trust

# ── Resumo ────────────────────────────────────────────────────────────────────
Write-Host "`n══════════════════════════════════════════" -ForegroundColor Green
Write-Host " Ambiente pronto!" -ForegroundColor Green
Write-Host "══════════════════════════════════════════" -ForegroundColor Green
Write-Host @"

Se rodou fora do repo, abra um novo terminal (PATH atualizado) e:

  1. gh auth login
  2. git clone https://github.com/Gabriel-and-some-code-stuff/informE
  3. cd informE
  4. .\setup-dev.ps1        # agora sobe o banco e aplica migrations sozinho
  5. dotnet run --project src/Host/informE.Server
"@
