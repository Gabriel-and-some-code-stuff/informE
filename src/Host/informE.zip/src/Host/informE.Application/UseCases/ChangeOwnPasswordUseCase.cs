using informE.Application.Interfaces;
using informE.Application.Interfaces.Repositories;

namespace informE.Application.UseCases;

public class ChangeOwnPasswordUseCase(
    IUserRepository userRepository,
    IPasswordHasher passwordHasher,
    IUnitOfWork unitOfWork)
{
    public async Task ExecuteAsync(Guid userId, string senhaAtual, string novaSenha, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(senhaAtual))
            throw new ArgumentException("Informe a senha atual.");

        if (string.IsNullOrWhiteSpace(novaSenha) || novaSenha.Length < 8)
            throw new ArgumentException("A nova senha deve ter pelo menos 8 caracteres.");

        var user = await userRepository.GetByIdAsync(userId, ct)
            ?? throw new UnauthorizedAccessException("Usuário não encontrado.");

        if (!passwordHasher.Verify(senhaAtual, user.PasswordHash))
            throw new ArgumentException("A senha atual está incorreta.");

        user.ChangePassword(passwordHasher.Hash(novaSenha));
        await unitOfWork.SaveChangesAsync(ct);
    }
}
