namespace informE.Domain.Enums;

public enum RamType { DDR3, DDR4, DDR5 }
